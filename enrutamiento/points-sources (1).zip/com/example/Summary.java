
package com.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cost",
    "unassigned",
    "delivery",
    "amount",
    "pickup",
    "service",
    "duration",
    "waiting_time",
    "computing_times"
})
public class Summary {

    @JsonProperty("cost")
    private Integer cost;
    @JsonProperty("unassigned")
    private Integer unassigned;
    @JsonProperty("delivery")
    private List<Integer> delivery = null;
    @JsonProperty("amount")
    private List<Integer> amount = null;
    @JsonProperty("pickup")
    private List<Integer> pickup = null;
    @JsonProperty("service")
    private Integer service;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("waiting_time")
    private Integer waitingTime;
    @JsonProperty("computing_times")
    private ComputingTimes computingTimes;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cost")
    public Integer getCost() {
        return cost;
    }

    @JsonProperty("cost")
    public void setCost(Integer cost) {
        this.cost = cost;
    }

    @JsonProperty("unassigned")
    public Integer getUnassigned() {
        return unassigned;
    }

    @JsonProperty("unassigned")
    public void setUnassigned(Integer unassigned) {
        this.unassigned = unassigned;
    }

    @JsonProperty("delivery")
    public List<Integer> getDelivery() {
        return delivery;
    }

    @JsonProperty("delivery")
    public void setDelivery(List<Integer> delivery) {
        this.delivery = delivery;
    }

    @JsonProperty("amount")
    public List<Integer> getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(List<Integer> amount) {
        this.amount = amount;
    }

    @JsonProperty("pickup")
    public List<Integer> getPickup() {
        return pickup;
    }

    @JsonProperty("pickup")
    public void setPickup(List<Integer> pickup) {
        this.pickup = pickup;
    }

    @JsonProperty("service")
    public Integer getService() {
        return service;
    }

    @JsonProperty("service")
    public void setService(Integer service) {
        this.service = service;
    }

    @JsonProperty("duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    @JsonProperty("waiting_time")
    public Integer getWaitingTime() {
        return waitingTime;
    }

    @JsonProperty("waiting_time")
    public void setWaitingTime(Integer waitingTime) {
        this.waitingTime = waitingTime;
    }

    @JsonProperty("computing_times")
    public ComputingTimes getComputingTimes() {
        return computingTimes;
    }

    @JsonProperty("computing_times")
    public void setComputingTimes(ComputingTimes computingTimes) {
        this.computingTimes = computingTimes;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
