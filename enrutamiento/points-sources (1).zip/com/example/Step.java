
package com.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "location",
    "load",
    "arrival",
    "duration",
    "id",
    "service",
    "waiting_time",
    "job"
})
public class Step {

    @JsonProperty("type")
    private String type;
    @JsonProperty("location")
    private List<Double> location = null;
    @JsonProperty("load")
    private List<Integer> load = null;
    @JsonProperty("arrival")
    private Integer arrival;
    @JsonProperty("duration")
    private Integer duration;
    @JsonProperty("id")
    private Integer id;
    @JsonProperty("service")
    private Integer service;
    @JsonProperty("waiting_time")
    private Integer waitingTime;
    @JsonProperty("job")
    private Integer job;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("location")
    public List<Double> getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(List<Double> location) {
        this.location = location;
    }

    @JsonProperty("load")
    public List<Integer> getLoad() {
        return load;
    }

    @JsonProperty("load")
    public void setLoad(List<Integer> load) {
        this.load = load;
    }

    @JsonProperty("arrival")
    public Integer getArrival() {
        return arrival;
    }

    @JsonProperty("arrival")
    public void setArrival(Integer arrival) {
        this.arrival = arrival;
    }

    @JsonProperty("duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    @JsonProperty("id")
    public Integer getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Integer id) {
        this.id = id;
    }

    @JsonProperty("service")
    public Integer getService() {
        return service;
    }

    @JsonProperty("service")
    public void setService(Integer service) {
        this.service = service;
    }

    @JsonProperty("waiting_time")
    public Integer getWaitingTime() {
        return waitingTime;
    }

    @JsonProperty("waiting_time")
    public void setWaitingTime(Integer waitingTime) {
        this.waitingTime = waitingTime;
    }

    @JsonProperty("job")
    public Integer getJob() {
        return job;
    }

    @JsonProperty("job")
    public void setJob(Integer job) {
        this.job = job;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
